
# Text Classification Battle – SMS Spam Detection

## Problem Statement
Classify SMS messages into Ham and Spam using machine learning.

## Dataset
UCI SMS Spam Collection Dataset.

## Algorithms
1. Decision Tree
2. K-Nearest Neighbours
3. Support Vector Machine
4. Multinomial Naive Bayes

## Technologies
Python, Pandas, Scikit-learn, Matplotlib, Seaborn.

## Methodology
Text preprocessing, TF-IDF feature extraction and stratified
80:20 train-test split.

## Evaluation Metrics
Accuracy, Precision, Recall and F1-score.

## What-if Experiment
Compared TF-IDF unigrams (1,1) against unigrams + bigrams (1,2).

## Best Configuration
SVM with unigrams + bigrams, selected based on experimental F1-score.

## Outputs
See the outputs folder for CSV results, graphs and confusion matrices.

## Reports
See the reports folder for classification reports and experiment summary.
